package net.ent.etrs.model.entities.references;

public enum Couleur {

    BORDEAUX,
    JAUNE,
    GRIS,
    BLANC,
    ROSE,
    NOIR,
    ROUGE;

    Couleur() {
    }


}
